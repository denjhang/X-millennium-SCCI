
#ifdef __cplusplus
extern "C" {
#endif

BYTE mousemng_getstat(SINT16 *x, SINT16 *y, int clear);

#ifdef __cplusplus
}
#endif

