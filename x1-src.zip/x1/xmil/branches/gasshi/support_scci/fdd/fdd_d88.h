
#ifdef __cplusplus
extern "C" {
#endif

BRESULT fddd88_set(FDDFILE fdd, const OEMCHAR *fname);
void fddd88_eject(FDDFILE fdd);

#ifdef __cplusplus
}
#endif

