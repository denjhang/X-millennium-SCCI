
#ifdef __cplusplus
extern "C" {
#endif

void makex1font(REG8 loading);

#ifdef __cplusplus
}
#endif

