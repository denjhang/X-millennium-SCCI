
#define	advsys_task()			(TRUE)

#include	"advvideo.h"
#include	"advsound.h"
#include	"advkey.h"

