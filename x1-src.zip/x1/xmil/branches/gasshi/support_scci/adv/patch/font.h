
#define	FONTX1_LR	0x10000
#define	FONTX1T_LR	0x20000

#define	font_txt		__extromimage.txt
#define	font_knjx1		__extromimage.knjx1
#define	font_knjx1t		__extromimage.knjx1t

#define font_load(p, f)		(SUCCESS)


#ifdef __cplusplus
extern "C" {
#endif

extern	UINT8	font_ank[0x800];

#ifdef __cplusplus
}
#endif

