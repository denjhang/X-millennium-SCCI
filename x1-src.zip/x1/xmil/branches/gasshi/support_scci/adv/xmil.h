
typedef struct {
	UINT8	NOWAIT;
	UINT8	DRAW_SKIP;
} XMILOSCFG;


#ifdef __cplusplus
extern "C" {
#endif

extern	XMILOSCFG	xmiloscfg;

#ifdef __cplusplus
}
#endif

