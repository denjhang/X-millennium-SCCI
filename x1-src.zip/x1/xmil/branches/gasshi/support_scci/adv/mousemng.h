
#ifdef __cplusplus
extern "C" {
#endif

REG8 mousemng_getstat(SINT16 *x, SINT16 *y, BRESULT clear);

#ifdef __cplusplus
}
#endif

