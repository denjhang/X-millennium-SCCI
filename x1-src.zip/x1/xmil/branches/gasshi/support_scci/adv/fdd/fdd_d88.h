
#ifdef __cplusplus
extern "C" {
#endif

BRESULT fddd88_set(FDDFILE fdd, const UINT8 *romptr, UINT romsize);
void fddd88_eject(FDDFILE fdd);

#ifdef __cplusplus
}
#endif

