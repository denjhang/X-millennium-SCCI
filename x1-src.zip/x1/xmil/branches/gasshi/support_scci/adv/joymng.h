
#ifdef __cplusplus
extern "C" {
#endif

void joymng_setflags(void);

#ifdef __cplusplus
}
#endif

#define	joymng_getstat()			(0xff)

