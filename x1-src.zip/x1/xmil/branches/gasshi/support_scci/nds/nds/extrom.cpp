#include "compiler.h"

__attribute__((aligned(4))) const ROMIMG __extromimage = {{'R','O','M','A','R','E','A'}};

