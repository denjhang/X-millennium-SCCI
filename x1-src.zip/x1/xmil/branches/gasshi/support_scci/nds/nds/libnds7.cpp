#include "compiler.h"
#include "libnds.h"


int main()
{
	return nds7main();
}

