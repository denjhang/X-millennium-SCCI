
void softkbd9_initialize(void);
void softkbd9_sync(void);

