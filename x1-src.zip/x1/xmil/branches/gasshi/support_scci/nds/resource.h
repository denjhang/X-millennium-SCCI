
extern const unsigned int g_sDemoBmp[];

extern const unsigned short g_sDemoPal[];

