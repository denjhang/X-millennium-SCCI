
// #include "opmgen.h"
// #include "psggen.h"

#define	sndctrl_initialize()
#define sndctrl_deinitialize()
#define sndctrl_reset()

