
void joymng_setflags();

#define	joymng_getstat()			(0xff)

