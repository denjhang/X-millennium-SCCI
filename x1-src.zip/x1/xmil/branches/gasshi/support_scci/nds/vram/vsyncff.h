
#ifdef __cplusplus
extern "C"
{
#endif

void vsyncff_init();
void vsyncff_int();
void vsyncff_turn(REG8 en);

#ifdef __cplusplus
}
#endif

