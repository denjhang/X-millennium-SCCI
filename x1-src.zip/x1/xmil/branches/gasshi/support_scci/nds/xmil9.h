
struct tagXmilOsCfg
{
	UINT8 NOWAIT;
	UINT8 DRAW_SKIP;
};
typedef struct tagXmilOsCfg		XMILOSCFG;


#ifdef __cplusplus
extern "C"
{
#endif

extern	XMILOSCFG	xmiloscfg;

#ifdef __cplusplus
}
#endif

