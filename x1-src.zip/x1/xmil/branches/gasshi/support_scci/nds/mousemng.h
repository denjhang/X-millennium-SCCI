
#ifdef __cplusplus
extern "C"
{
#endif

REG8 mousemng_getstat(SINT16 *pwX, SINT16 *pwY, BRESULT bClear);

#ifdef __cplusplus
}
#endif

