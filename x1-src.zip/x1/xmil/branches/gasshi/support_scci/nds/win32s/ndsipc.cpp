#include "compiler.h"
#include "libnds.h"


	UINT8 g_sIPC[0x1000];

