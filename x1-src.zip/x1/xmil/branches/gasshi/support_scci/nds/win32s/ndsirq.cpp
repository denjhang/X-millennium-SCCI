#include "compiler.h"
#include "libnds.h"


void irqInit()
{
}

void irqSet(tagNdsIrq nMask, void (*handler)())
{
}

void irqEnable(uint32 uMask)
{
}

