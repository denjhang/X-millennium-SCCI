
void dmaCopy(LPCVOID lpvSrc, LPVOID lpvDst, int nSize);

