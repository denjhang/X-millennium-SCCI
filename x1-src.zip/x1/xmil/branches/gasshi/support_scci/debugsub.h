
#ifdef __cplusplus
extern "C" {
#endif

void debugsub_status(void);

#ifdef __cplusplus
}
#endif

