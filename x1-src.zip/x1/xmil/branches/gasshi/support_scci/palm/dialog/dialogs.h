
BOOL dlgs_selectfile(char *name);
BOOL dlgs_selectwritefile(char *name, int size, const char *def);
