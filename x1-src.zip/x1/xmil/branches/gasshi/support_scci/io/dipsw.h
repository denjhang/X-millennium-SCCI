
#ifdef __cplusplus
extern "C" {
#endif

REG8 IOINPCALL dipsw_i(UINT port);

#ifdef __cplusplus
}
#endif

